
import epsagon


epsagon.init(
    '87a6f6b4-b796-455d-9d5e-bba5119c7d87',
    'tf-app',
    metadata_only=False,
)


@epsagon.lambda_wrapper
def handler(event, context):

    x = 3

    epsagon.label('x_value', x)

    return {
        'statusCode': 200,
    }