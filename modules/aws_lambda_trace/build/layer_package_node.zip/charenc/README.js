**enc** provides crypto character encoding utilities.
