# This file is protected via CODEOWNERS
__version__ = "1.25.11"
