# 1.1.0

  * Downgraded to ES5-compatible code
  * Marked as no longer maintained

# 1.0.0

  * Forked from node-uuid in order to recover and expose parse/unparse commands
