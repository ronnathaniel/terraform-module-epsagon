
# import requests


def handler(event, context):

    x = 3


#     res = requests.get('https://example.com')

    return {
#         'status': res.status_code,
        'statusCode': 200,
    }